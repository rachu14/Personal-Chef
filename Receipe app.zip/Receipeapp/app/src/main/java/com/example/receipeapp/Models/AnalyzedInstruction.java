package com.example.receipeapp.Models;

import java.util.ArrayList;

@SuppressWarnings("ALL")
public class AnalyzedInstruction {
    @SuppressWarnings("unused")
    public String name;
    @SuppressWarnings("unused")
    public ArrayList<Step> steps;
}
