package com.example.receipeapp.Models;

public class Measures {
    public Us us;
    public Metric metric;
}
