package com.example.receipeapp.Models;

public class Length {
    public int number;
    public String unit;
}
