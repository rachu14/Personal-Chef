package com.example.receipeapp.Models;

public class Temperature {
    public double number;
    public String unit;
}
