package com.example.receipeapp.Listeners;

public interface RecipeClickListener {
    void onRecipeClicked(String id);
}
