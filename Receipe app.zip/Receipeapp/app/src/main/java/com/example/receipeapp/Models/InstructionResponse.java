package com.example.receipeapp.Models;

import java.util.ArrayList;

public class InstructionResponse {
    @SuppressWarnings("unused")
    public String name;
    public ArrayList<Step> steps;
}
