package com.example.receipeapp.Models;

public class Metric {
    public double amount;
    public String unitShort;
    public String unitLong;
}
